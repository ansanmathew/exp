#include <iostream>
using namespace std;
int main()
{
	int x,z,result;
	char oper,rep;
	do
{
cout <<"please enter the operand of the problem you would like to solve:"<<endl;
cout <<"+ for addition"<<endl;
cout <<"- fro subtraction"<<endl;
cout <<"* for multiplication"<<endl;
cout <<"/ for division"<<endl;
cout <<"% for division(remainder)"<<endl;
cin >> oper;
cout <<"please enter two numbers for calculation ==>";
cin>>x>>z;
switch(oper)
{case '+':
	result=x+z;
	cout <<"the answer is:" <<result <<endl;
	break;
case '-':
	result=x-z;
	cout <<"The answer is :"<<result<<endl;
	break;
case '*':
	result= x*z;
	cout <<"The answer is :"<<result<<endl;
	break;
case '/':
	if (z==0)
	{cout << " that is an invalid operation"<<endl;
	}
else{	
	result = x/z;
	cout<< "the answer is:"<<result<<endl;
	}
	break;
case '%':
	if(z==0)
	{cout <<"this is an invalid operation"<<endl;
	}
else
	{result = x%z;
	cout<<"the answer is"<<result<<endl;
	}
	break;
default:
	cout<<"that is an invalid operation"<<endl;
	break;
}
	cout<<"do you want to continue?(y/n):";
	cin>>rep;
}
while (rep == 'y' || rep == 'y');
}
	
