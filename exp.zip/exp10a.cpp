#include<iostream>
using namespace std;
class student
{
protected:
	int rno,m1,m2;
public:
	void get()
    {
	cout<<"Enter roll number ";
	cin>>rno;
	cout<<"Enter Mark 1 ";
	cin>>m1;
	cout<<"Enter Mark 2 ";
	cin>>m2;
    }
};
class sports
{
protected:
	int sm;
public:
	void getsm()
{
	cout<<"Enter Sports Mark ";
	cin>>sm;
    }
};
class statement:public student,public sports
{
int tot,avg;
public:
	void display()
	{
		tot=(m1+m2+sm);
		avg=tot/3;
		cout<<"Roll Number :"<<rno<<endl
			<<"Mark 1 "<<m1<<endl
			<<"Mark 2 "<<m2<<endl
			<<"Total "<<tot<<endl
			<<"Average "<<avg<<endl;
	}
};
int main()
{
	statement obj;
	obj.get();
	obj.getsm();
	obj.display();
}
