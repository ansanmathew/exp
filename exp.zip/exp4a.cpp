#include<iostream>
using namespace std;
int fibnoacci(int);
int main()
{
	int n;
	cout<<"Enter a number :";
	cin>>n;
	for(int i=1;i<=n;i++)
	cout<<fibnoacci(i)<<"\t";
}
int fibnoacci(int n)
{
	if(n<=2)
		return 1;
	else
		return(fibnoacci(n-1)+fibnoacci(n-2));
}
