#include<iostream>
using namespace std;

template <class T>
class mypair{
	T a, b;
public:
	mypair (T first, T second)
	{
		a=first;
		b=second;
	}
	T getmax ();
};
template <class T>
T mypair<T>::getmax()
{
	T retval;
	retval = a>b? a : b;
return retval;
}
int main()
{
	int n1, n2;
	cout<<" Enter two integer values :" ;
	cin>> n1>>n2 ;
	mypair<int> myobject1(n1,n2);
	cout<<"Largest is "<<myobject1.getmax()<<endl;
	
	float f1, f2;
	cout<<" Enter two float values :" ;
	cin>> f1>>f2 ;
	mypair<float> myobject2(f1,f2);
	cout<<"Largest is "<<myobject2.getmax()<<endl;
}
