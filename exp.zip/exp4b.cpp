#include<iostream>
using namespace std;

struct student
{
	char name[40];
	float mark1,mark2,mark3;
	float avg;
}s;
void read_student();
void calculate_avg();
void display_student();
int main()
{
	read_student();
	calculate_avg();
	display_student();
}
void read_student()
{
	cout<<"Student Name : ";
	cin>>s.name;
	cout<<"Enter 3 Marks : ";
	cin>>s.mark1>>s.mark2>>s.mark3;
}
void calculate_avg()
{
	s.avg=(s.mark1+s.mark2+s.mark3)/3;
}
void display_student()
{
	cout<<"Student Name : "<<s.name<<"\n"
	<<"Mark 1 :"<<s.mark1<<"\n"
	<<"Mark 2 :"<<s.mark2<<"\n"
	<<"Mark 3 :"<<s.mark3<<"\n"
	<<"Average : "<<s.avg<<endl;
}
