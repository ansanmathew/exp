#include<iostream>
using namespace std;
int main()
{
	char line[80];
	int i = 0,count=0;
	cout<<"Enter a line of text";
	cin.getline(line,80);
	while(line[i]!='\0')
	{
	if(line[i]=='a'||line[i]=='A'
	||line[i]=='e'||line[i]=='E'
	||line[i]=='i'||line[i]=='I'
	||line[i]=='o'||line[i]=='O'
	||line[i]=='u'||line[i]=='U')
		count++;
	i++;
}
cout<<"There is"<<count<<"vowels characters"<<endl;
}
