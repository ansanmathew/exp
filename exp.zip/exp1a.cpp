#include <iostream>
using namespace std;
int main(){
    int units;
    float charge;
    char cust_name[30];
    cout<<"customer_name:";
    cin>>cust_name;
    cout<<"unit_consumed:";
    cin>>units;
    if (units <100)
        charge=units*0.6;
    else if(units<300)
        charge=60+(units-100)*0.8;
    else
        charge = 220+(units-300)*0.9;
    if (charge<50)
        charge=50;
    if (charge>300)
        charge+= charge*0.15;
    cout<<"customer_name:"<<cust_name<<endl
        <<"units consumed:"<<units<<endl
        <<"charge:"<<charge<<endl;

}

