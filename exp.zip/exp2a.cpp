#include <iostream>
using namespace std;
struct distance
{
	int inch;
	int feet;
};
	int main()
{
struct distance d1,d2;
struct distance d3 = {0,0};
cout <<"enter distance 1:";
cin>>d1.feet>>d1.inch;
cout<<"enter distance 2:";
cin>>d2.feet>>d2.inch;
d3.inch = d1.inch + d2.inch;
if(d3.inch >= 12)
{
	d3.feet = 1;
	d3.inch -=12;
}
d3.feet += (d2.feet + d2.feet);
cout <<d1.feet <<"\""<<d1.inch<<"\""<<endl;
cout <<d2.feet <<"\""<<d2.inch<<"\""<<endl;
cout <<d3.feet <<"\""<<d3.inch<<"\""<<endl;
}
