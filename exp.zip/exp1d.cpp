#include <iostream>
using namespace std;
int main()
{
int candidate[6] = {0,0,0,0,0,0};
int option;
char repeatornot;
do
{cout <<"please enter the serial number of the candidate you would like to vote:"<<endl;
cout<<"1 for candidate 1"<<endl;
cout<<"2 for candidate 2"<<endl;
cout<<"3 for candidate 3"<<endl;
cout<<"4 for candidate 4"<<endl;
cout<<"5 for candidate 5"<<endl;
cout<<"enter your choice==>"<<endl;
cin>>option;
if (option>=1 && option <=5)
	candidate [option]++;
else candidate[0]++;
	cout<<"do you want to continue?(y/n)";
	cin>>repeatornot;
}
while (repeatornot =='y'||repeatornot=='y');
	cout<<"result"<<endl;
	cout<<"spoil Ballot:"<<candidate[0]<<endl;
	for(int i=1;i<=5;i++)
	cout<<"candidate"<<i<<":"<<candidate[i]<<endl;
}
