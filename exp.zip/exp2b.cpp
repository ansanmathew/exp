#include <iostream>
using namespace std;
union element
{
	int i_ele;
	double d_ele;
};
int main()
{
	union element vector[10];
	int option,n;
	cout<<"1.Create Integer vector"
		<<"2.Create Double Vector";
	cout<<"Enter option:";
	cin>>option;
	cout<<"enter size of vector:";
	cin>>n;
	if(option==1)
		{
			cout<<"enter elements of integer vector:";
			for(int i = 0;i<n;i++)
				cin>>vector[i].i_ele;
			for(int i = 0;i<n;i++)
			 	cout<<vector[i].i_ele<<"\t";
			 	
		}
	else if(option ==2)
			{
				cout<<"enter elements of double vector:";
				for(int i = 0;i<n;i++)
					cin>>vector[i].d_ele;
				for(int i =0;i<n;i++)
					cout<<vector[i].d_ele<<"\t";
			}
			else
				cout<<"Invalid option"<<endl;
	}
