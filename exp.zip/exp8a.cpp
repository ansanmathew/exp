#include<iostream>
#include<string.h>
using namespace std;
class account
{
	char name[50];
	long int accountnumber;
	char type[10];
	double balance;
	static float rate;
public :
	account()
    {
	strcpy(name,"");
	strcpy(type,"");
    accountnumber=0;
	balance=0;
	cout<<"Default constructor executed "<<endl;
}
account(const account &t)
{
	strcpy(name,t.name);
	strcpy(type,t.type);
    accountnumber=t.accountnumber;
	balance=t.balance;
	cout<<"Copy constructor executed "<<endl;
}
account(char*,int,char*,double);
static float getrate();
    void print();
void deposit(double d)
{
    balance=balance+d;
}
    void withdraw(double d)
{
    if(d<=balance)
	balance-=d;
    else
	cout<<"You do not have sufficient balance "<<endl;
}
    ~account()
    {
	cout<<"Destructor executed"<<endl;
    }
};
account::account(char* n,int an,char* t,double b)
{
	strcpy(name,n);
	    strcpy(type,t);
	accountnumber=an;
	    balance=b;
	    cout<<"Parameterized constructor executed "<<endl;
}
float account::getrate()
{
    return rate;
}
void account::print()
{
	cout<<"Customer name : "<<name<<endl;
	cout<<"Account number : "<<accountnumber<<endl;
	cout<<"Account type : "<<type<<endl;
	cout<<"Balance : "<<balance<<endl;
	cout<<"Rate : "<<rate<<endl;
}
float account::rate=7.5;
int main()
{
	account a;
	a.print();
	account b("Ravi",2345,"Savings",500);
	account c=b;
	c.print();
	c.deposit(2300);
	c.print();
	c.withdraw(2000);
	c.print();
	c.withdraw(2000);
	c.print();
	cout<<"Interest rate :"<<account::getrate()<<endl;
}
